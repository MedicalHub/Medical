Leo White CG Artist.


ABOUT ME
--------
Leo White, freelance 3D Artist based in Russia.
I share my life and passion for 3d models.
I am always available for interesting collaboration.


SOFTWARE
--------
>Lightwave 3D
>Adobe Photoshop


AREA OF EXPERTISE
-----------------
>Lowpoly and HighPoly
>3D Anatomy/Creature/Character modelling
>Texturing
>Digital art

MY BRANDS
---------
>Rembex
>Leo3dmodels

YOU FIND ME HERE
----------------
>Rembex:
https://www.the3dstudio.com/product_search.aspx?id_author=327223

>Leo3dmodels:
http://www.turbosquid.com/Search/Artists/leo3Dmodels


CONTACT
-------
leo3dmodels@gmail.com
