
Appointments = new Mongo.Collection("appointments");
Notifications = new Mongo.Collection("notifications");