meteor-node-imap
================

Meteor smart package of the node-imap module.
