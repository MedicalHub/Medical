var head = document.getElementsByTagName('head')[0];

//Generate a style tag
var style1 = document.createElement('link');
style1.type = 'text/css';
style1.rel = "stylesheet";
style1.href = '/style.css';

head.appendChild(style1);
