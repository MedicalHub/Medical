DocSchema = {};
Doctor = new Mongo.Collection("doctor");
