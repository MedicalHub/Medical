Template.ReactiveSunburst.helpers({
	id: function () {
		return (this.options.id || "Sunburst") + "_wrapper";
	}
});

Template.ReactiveSunburst.onRendered(function () {
	var data = this.data;
	var sunburst = new ReactiveSunburst(data.options);
	this.autorun(function () {
		sunburst.update();
		sunburst.autorunFunctions();
	});
});