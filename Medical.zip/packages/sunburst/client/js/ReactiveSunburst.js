ReactiveSunburst = function (options) {
	if (!jQuery.isFunction(options.events)) {
		throw new SyntaxError("Need events options declaring a function to manage reactive data");
	}

	var sunburst = document.createElement('div');
	(!options.id) ? sunburst.id = "Sunburst": sunburst.id = options.id;
	(!options.addedClasses) ? sunburst.className = "sunburst": sunburst.className = "sunburst " + options.addedClasses;
	$("#" + sunburst.id + "_wrapper").append(sunburst);
	
	var svg = sunburst.append("svg")
	.attr("width", margin.left + margin.right)
	.attr("height", margin.top + margin.bottom)
	.append("g")
	.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
	d3.json(options.json, function (error, root) {
	if (error) return console.warn(error);
	// Compute the initial layout on the entire tree to sum sizes.
	// Also compute the full name and fill color for each node,
	// and stash the children so they can be restored as we descend.

	partition
		.value(function (d) {
			return d.size;
		})
		.nodes(root)
		.forEach(function (d) {
			d._children = d.children;
			d.sum = d.value;
			d.key = key(d);
			d.fill = fill(d);
		});

	// Now redefine the value function to use the previously-computed sum.
	partition
		.children(function (d, depth) {
			return depth < 2 ? d._children : null;
		})
		.value(function (d) {
			return d.sum;
		});

	var center = svg.append("circle")
		.attr("r", radius / 3)
		.on("click", zoomOut);

	center.append("title")
		.text("zoom out");

	var partitioned_data = partition.nodes(root).slice(1)

	var path = svg.selectAll("path")
		.data(partitioned_data)
		.enter().append("path")
		.attr("d", arc)
		.style("fill", function (d) {
			return d.fill;
		})
		.each(function (d) {
			this._current = updateArc(d);
		})
		.on("click", zoomIn)
		.on("mouseover", mouseOverArc)
		.on("mousemove", mouseMoveArc)
		.on("mouseout", mouseOutArc);


	var texts = svg.selectAll("text")
		.data(partitioned_data)
		.enter().append("text")
		.filter(filter_min_arc_size_text)
		.attr("transform", function (d) {
			return "rotate(" + computeTextRotation(d) + ")";
		})
		.attr("x", function (d) {
			return radius / 3 * d.depth;
		})
		.attr("dx", "6") // margin
		.attr("dy", ".35em") // vertical-align	
		.text(function (d, i) {
			return d.name
		})

	function zoomIn(p) {
		if (p.depth > 1) p = p.parent;
		if (!p.children) return;
		zoom(p, p);
	}

	function zoomOut(p) {
		if (!p.parent) return;
		zoom(p.parent, p);
	}

	// Zoom to the specified new root.
	function zoom(root, p) {
		if (document.documentElement.__transition__) return;

		// Rescale outside angles to match the new layout.
		var enterArc,
			exitArc,
			outsideAngle = d3.scale.linear().domain([0, 2 * Math.PI]);

		function insideArc(d) {
			return p.key > d.key ? {
				depth: d.depth - 1,
				x: 0,
				dx: 0
			} : p.key < d.key ? {
				depth: d.depth - 1,
				x: 2 * Math.PI,
				dx: 0
			} : {
				depth: 0,
				x: 0,
				dx: 2 * Math.PI
			};
		}

		function outsideArc(d) {
			return {
				depth: d.depth + 1,
				x: outsideAngle(d.x),
				dx: outsideAngle(d.x + d.dx) - outsideAngle(d.x)
			};
		}

		center.datum(root);

		// When zooming in, arcs enter from the outside and exit to the inside.
		// Entering outside arcs start from the old layout.
		if (root === p) enterArc = outsideArc, exitArc = insideArc, outsideAngle.range([p.x, p.x + p.dx]);

		var new_data = partition.nodes(root).slice(1)

		path = path.data(new_data, function (d) {
			return d.key;
		});

		// When zooming out, arcs enter from the inside and exit to the outside.
		// Exiting outside arcs transition to the new layout.
		if (root !== p) enterArc = insideArc, exitArc = outsideArc, outsideAngle.range([p.x, p.x + p.dx]);

		d3.transition().duration(d3.event.altKey ? 7500 : 750).each(function () {
			path.exit().transition()
				.style("fill-opacity", function (d) {
					return d.depth === 1 + (root === p) ? 1 : 0;
				})
				.attrTween("d", function (d) {
					return arcTween.call(this, exitArc(d));
				})
				.remove();

			path.enter().append("path")
				.style("fill-opacity", function (d) {
					return d.depth === 2 - (root === p) ? 1 : 0;
				})
				.style("fill", function (d) {
					return d.fill;
				})
				.on("click", zoomIn)
				.on("mouseover", mouseOverArc)
				.on("mousemove", mouseMoveArc)
				.on("mouseout", mouseOutArc)
				.each(function (d) {
					this._current = enterArc(d);
				});


			path.transition()
				.style("fill-opacity", 1)
				.attrTween("d", function (d) {
					return arcTween.call(this, updateArc(d));
				});



		});


		texts = texts.data(new_data, function (d) {
			return d.key;
		})

		texts.exit()
			.remove()
		texts.enter()
			.append("text")

		texts.style("opacity", 0)
			.attr("transform", function (d) {
				return "rotate(" + computeTextRotation(d) + ")";
			})
			.attr("x", function (d) {
				return radius / 3 * d.depth;
			})
			.attr("dx", "6") // margin
			.attr("dy", ".35em") // vertical-align
			.filter(filter_min_arc_size_text)
			.text(function (d, i) {
				return d.name
			})
			.transition().delay(750).style("opacity", 1)


	}
});


	this.autorunFunctions = function () {
		if (options.autoruns) {
			options.autoruns.forEach(function (funcDef) {
				funcDef();
			});
		}
	};
};

ReactiveFullsunburst.prototype.update = function () {
	//this.sunburst.sunburst('refetchEvents');
};