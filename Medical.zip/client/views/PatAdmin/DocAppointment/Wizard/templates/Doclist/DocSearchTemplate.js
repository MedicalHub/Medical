Template.DocSearchTemplate.helpers({
  c_Doc: function() {
    return Doctor.find();
  }
});


