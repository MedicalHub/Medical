Template.Workplace.helpers({
  c_Workplace: function() {
    return Workplace.find();
  }
});


