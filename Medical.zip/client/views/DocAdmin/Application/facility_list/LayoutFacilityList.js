Template.LayoutFacilityList.helpers({
  type: function() {
    return this.type;
  },
  address : function() {
    return this.address;
  }
});
