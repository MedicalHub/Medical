Template.FormWizard.nam = function () {
    return Doctor.findOne();
};
