Template.Flipster.rendered = function () {
$(".coverflow").flipster();
}
