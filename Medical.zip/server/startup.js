Meteor.startup(function(){

SimpleSchema.debug = true;
});